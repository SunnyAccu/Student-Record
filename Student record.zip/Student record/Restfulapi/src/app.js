const express=require('express')
require("./db/conn")
const Student=require("./models/student")
const studentRouter=require('./Router/routers')
const app=express()
const port=process.env.PORT || 3000

app.use(express.json()) // it will convert the text in json 
app.use(studentRouter)

// Create a new student
app.listen(port,()=>{
    console.log(`connection is setup at ${port}`)
})