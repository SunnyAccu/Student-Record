const express=require('express')
const router=new express.Router()
const Student=require('../models/student')
router.post('/students',async(req,res)=>{
    try{
        const user=new Student(req.body)
        const createUser=await user.save() /// it will save data in database    
        res.status(201).send(createUser)
    }catch(e){
        res.status(400).send(e)
    }
})


// Read all Record

router.get('/students',async(req,res)=>{
    try{
        const studentsData =await Student.find()
        res.send(studentsData)
    }catch(e){
        res.status(400).send(e)
    }
})

// Get the individual student data using data

router.get('/students/:id',async(req,res)=>{
    try{
        const _id=req.params.id
        const studentdata=await Student.findById(_id)
        if(!studentdata){
            return res.status(404).send()
        }else{
            res.send(studentdata)
        }
    }catch(e){
        res.status(500).send(e)
    }
})
// update the student record by its id
router.patch('/students/:id',async(req,res)=>{
    try{
        const _id=req.params.id
        const updatestudent=await Student.findByIdAndUpdate(_id,req.body,{new:true})
        res.send(updatestudent)


    }catch(e){
        res.status(500).status(e)
    }
})



// delete the student by id
router.delete('/students/:id',async(req,res)=>{
    try{
        const studentdelete=await Student.findByIdAndDelete(req.params.id)
        if (!req.params.id){
            return res.status(400).send()
        }
        res.send(studentdelete)
    }catch(e){
        res.status(500).send(e)
    }
})





module.exports=router;